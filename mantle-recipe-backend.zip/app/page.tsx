"use client"

import app from "../server"

export default function SyntheticV0PageForDeployment() {
  return <app />
}